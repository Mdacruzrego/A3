
package MODELS;

public class NovoPontoModel {

   
    
private String endereco;
private String cep;
private String bairro;
private String tipoMaterial;
private String horaColeta;

    public NovoPontoModel(String endereço, String cep, String bairro, String tipoMaterial, String horaColeta) {
        this.endereco = endereço;
        this.cep = cep;
        this.bairro = bairro;
        this.tipoMaterial = tipoMaterial;
        this.horaColeta = horaColeta;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereço) {
        this.endereco = endereço;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getTipoMaterial() {
        return tipoMaterial;
    }

    public void setTipoMaterial(String tipoMaterial) {
        this.tipoMaterial = tipoMaterial;
    }

    public String getHoraColeta() {
        return horaColeta;
    }

    public void setHoraColeta(String horaColeta) {
        this.horaColeta = horaColeta;
    }

   

    
}
