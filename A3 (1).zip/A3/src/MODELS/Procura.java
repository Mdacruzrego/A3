
package MODELS;

public class Procura {
private String endereço;
private String tipoDeMaterial;
private String horarioColeta;

    public Procura(String endereço, String tipoDeMaterial, String horarioColeta) {
        this.endereço = endereço;
        this.tipoDeMaterial = tipoDeMaterial;
        this.horarioColeta = horarioColeta;
    }

    public String getEndereço() {
        return endereço;
    }

    public void setEndereço(String endereço) {
        this.endereço = endereço;
    }

    public String getTipoDeMaterial() {
        return tipoDeMaterial;
    }

    public void setTipoDeMaterial(String tipoDeMaterial) {
        this.tipoDeMaterial = tipoDeMaterial;
    }

    public String getHorarioColeta() {
        return horarioColeta;
    }

    public void setHorarioColeta(String horarioColeta) {
        this.horarioColeta = horarioColeta;
    }

    
}
