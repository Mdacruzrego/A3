
package REPOSITORY;
import MODELS.NovoPontoModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class novoPontoRepository {
 Connection conexao;
 
 public void createNovoPonto(NovoPontoModel coleta){
     try {
         String sql = "insert into novoponto (endereco, cep, bairro, tipoMaterial, horaColeta) values (?,?,?,?,?)";
         conexao = new ConectarLogin().conectaBD();
         
         PreparedStatement statement = conexao.prepareStatement(sql);
         statement.setString(1,coleta.getEndereco()); 
         statement.setString(2,coleta.getCep()); 
         statement.setString(3,coleta.getBairro()); 
         statement.setString(4,coleta.getTipoMaterial()); 
         statement.setString(5,coleta.getHoraColeta()); 
         statement.execute();
         statement.close();
         
         
     } catch (SQLException ex) {
         JOptionPane.showMessageDialog(null, "Não foi possível adicionar um novo ponto !");
         Logger.getLogger(novoPontoRepository.class.getName()).log(Level.SEVERE, null, ex);
     }
 
 }
 
 
 public ArrayList<NovoPontoModel>readAllColeta(){
     return null;
    
}
 public void updateNovoPonto(NovoPontoModel conta){
        
        }
         public void deleteNovoPonto(NovoPontoModel conta){
        
        }{
    
}
}
