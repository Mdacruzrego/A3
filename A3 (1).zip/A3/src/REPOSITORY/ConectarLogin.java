
package REPOSITORY;
import java.sql.Connection;
import java.sql.DriverManager; 
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
       
public class ConectarLogin {
    static PreparedStatement prepareStatement(String sql) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
 public Connection conectaBD(){
     Connection conexao = null;
     try {
     String url =
             "jdbc:mysql://localhost:3306/eco_recicle?serverTimeZone=UTC";
     String usuario = "root";
     String senha = "cadebebe";
     conexao = DriverManager.getConnection(url, usuario, senha);
     
     } catch (SQLException ex) {
         JOptionPane.showMessageDialog(null, "Não foi possível conectar ao banco de dados ");
         Logger.getLogger(ConectarLogin.class.getName()).log(Level.SEVERE, null, ex);
     }
     
     return conexao;
     
 }   
}

