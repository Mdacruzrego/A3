
package REPOSITORY;

import MODELS.UsuarioModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class usuarioRepository {
 Connection conexao;
 
 public void createUsuario(UsuarioModel conta){
     try {
         String sql = "insert into usuario (nome, sobrenome, email, senha) values (?,?,?,?)";
         conexao = new  ConectarLogin().conectaBD();
         PreparedStatement statement = conexao.prepareStatement(sql);
         statement.setString(1,conta.getNome());
         statement.setString(2,conta.getSobrenome());
         statement.setString(3,conta.getEmail()); 
         statement.setString(4,conta.getSenha());
         statement.execute();
         statement.close();
         
     } catch (SQLException ex) {
         JOptionPane.showMessageDialog(null, "Não foi possível cadastrar um novo usuario !");
         Logger.getLogger(usuarioRepository.class.getName()).log(Level.SEVERE, null, ex);
     }
         
 }
 public ArrayList<UsuarioModel>readAllUsuario(){
     return null;
 }
 public void updateUsuario(UsuarioModel conta){
 }
  public void deleteUsuario(UsuarioModel contas){
        
 }
}
